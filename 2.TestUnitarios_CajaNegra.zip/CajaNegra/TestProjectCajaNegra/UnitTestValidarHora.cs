using System;
using Xunit;

using CajaNegra;

namespace TestProjectCajaNegra
{
    public class UnitTestValidarHora
    {
        [Fact]
        public void Validar_14_05_ShouldBeOK()
        {

            string hora = "14";
            string minutos = "05";

            string resultado = ValidarHora.Validar(hora, minutos);

            Assert.Equal("OK", resultado);

        }


        [Fact]
        public void Validar_SinParametro_ShouldBeError() //Clase equivalencia: 2.1
        {

            string hora = null;
            string minutos = "45";

            string resultado = ValidarHora.Validar(hora, minutos);

            Assert.Equal("Error", resultado);

        }

        [Fact]
        public void Validar_h_30_ShouldBeError() //Clase equivalencia: 4
        {

            string hora = "h";
            string minutos = "30";

            string resultado = ValidarHora.Validar(hora, minutos);

            Assert.Equal("Error", resultado);

        }

        [Fact]
        public void Validar_15_mm_ShouldBeError() //Clase equivalencia: 4
        {

            string hora = "15";
            string minutos = "mm";

            string resultado = ValidarHora.Validar(hora, minutos);

            Assert.Equal("Error", resultado);

        }

        [Fact]
        public void Validar_HoraMenor0_45_ShouldBeError() //Clase equivalencia: 6.1
        {

            string hora = "-1";
            string minutos = "45";

            string resultado = ValidarHora.Validar(hora, minutos);

            Assert.Equal("Error", resultado);

        }


        [Fact]
        public void Validar_12_MinutosMenor0_ShouldBeError() //Clase equivalencia: 6.2
        {

            string hora = "12";
            string minutos = "-45";

            string resultado = ValidarHora.Validar(hora, minutos);

            Assert.Equal("Error", resultado);

        }

       
        [Fact]
        public void Validar_HoraMayor23_45_ShouldBeError() //Clase equivalencia: 6.3
        {

            string hora = "24";
            string minutos = "45";

            string resultado = ValidarHora.Validar(hora, minutos);

            Assert.Equal("Error", resultado);

        }

        [Fact]
        public void Validar_23_MinutosMayor59_ShouldBeError() //Clase equivalencia: 6.4
        {

            string hora = "23";
            string minutos = "60";

            string resultado = ValidarHora.Validar(hora, minutos);

            Assert.Equal("Error", resultado);

        }


    }
}
