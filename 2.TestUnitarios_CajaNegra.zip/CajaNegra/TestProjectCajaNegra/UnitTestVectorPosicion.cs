using System;
using Xunit;

using CajaNegra;

namespace TestProjectCajaNegra
{
    public class UnitTestVectorPosicion
    {
        [Fact]
        public void Busqueda_3_Vector_1_2_3_ShouldBe3() //Clase equivalencia: 1,3,5
        {

            string numero = "3";
            string[] vector = {"1", "2", "3"};

            string resultado = VectorPosicion.Busqueda(numero, vector);

            Assert.Equal("3", resultado);

        }

        [Fact]
        public void Busqueda_4_Vector_1_2_3_ShouldBe_Menos1() //Clase equivalencia: 1,3,5
        {

            string numero = "4";
            string[] vector = { "1", "2", "3" };

            string resultado = VectorPosicion.Busqueda(numero, vector);

            Assert.Equal("-1", resultado);

        }

        [Fact]
        public void Busqueda_SinParametro_ShouldBeError() //Clase equivalencia: 2.1
        {

            string numero = null;
            string[] vector = { "1", "2", "3" };

            string resultado = VectorPosicion.Busqueda(numero, vector);

            Assert.Equal("Error", resultado);

        }

        [Fact]
        public void Busqueda_SinParametro_ShouldBe_Menos1() //Clase equivalencia: 1,3,5
        {

            string numero = "5";
            string[] vector = {};

            string resultado = VectorPosicion.Busqueda(numero, vector);

            Assert.Equal("-1", resultado);

        }

        [Fact]
        public void Busqueda_SinParametro2_ShouldBeError() //Clase equivalencia: 2.1
        {

            string numero = "5";
            string[] vector = null;

            string resultado = VectorPosicion.Busqueda(numero, vector);

            Assert.Equal("Error", resultado);

        }

        [Fact]
        public void Busqueda_SinParametros_ShouldBeError() //Clase equivalencia: 2.1
        {

            string numero = null;
            string[] vector = null;

            string resultado = VectorPosicion.Busqueda(numero, vector);

            Assert.Equal("Error", resultado);

        }

        [Fact]
        public void Busqueda_a_Vector_1_2_3_ShouldBeError() //Clase equivalencia: 4
        {

            string numero = "a";
            string[] vector = { "1", "2", "3" };

            string resultado = VectorPosicion.Busqueda(numero, vector);

            Assert.Equal("Error", resultado);

        }

        [Fact]
        public void Busqueda_3_Vector_a_b_c_ShouldBeError() //Clase equivalencia: 4
        {
            string numero = "3";
            string[] vector = { "a", "b", "c" };

            string resultado = VectorPosicion.Busqueda(numero, vector);

            Assert.Equal("Error", resultado);
        }


        [Fact]
        public void Busqueda_MenorMinEnteros_Vector_1_2_3_ShouldBeError() //Clase equivalencia: 6.1
        {
            string numero = "-2147483649";
            string[] vector = { "1", "2", "3" };

            string resultado = VectorPosicion.Busqueda(numero, vector);

            Assert.Equal("Error", resultado);
        }


        [Fact]
        public void Busqueda_MayorMaxEnteros_Vector_1_2_3_ShouldBeError() //Clase equivalencia: 6.2
        {
            string numero = "2147483648";
            string[] vector = { "1", "2", "3" };

            string resultado = VectorPosicion.Busqueda(numero, vector);

            Assert.Equal("Error", resultado);
        }

        [Fact]
        public void Busqueda_3_Vector_MenorMinEnteros_2_3_ShouldBeError() //Clase equivalencia: 6.3
        {
            string numero = "3";
            string[] vector = { "-2147483649", "2", "3" };

            string resultado = VectorPosicion.Busqueda(numero, vector);

            Assert.Equal("Error", resultado);
        }


        [Fact]
        public void Busqueda_3_Vector_1_2_MayorMaxEnteros_ShouldBeError() //Clase equivalencia: 6.4
        {
            string numero = "3";
            string[] vector = { "1", "2", "2147483648" };

            string resultado = VectorPosicion.Busqueda(numero, vector);

            Assert.Equal("Error", resultado);
        }


        [Fact]
        public void Busqueda_3_Vector_MinEnteros_2_3_ShouldBe3() //Clase equivalencia: 1,3,5
        {

            string numero = "3";
            string[] vector = { "-2147483648", "2", "3" };

            string resultado = VectorPosicion.Busqueda(numero, vector);

            Assert.Equal("3", resultado);

        }

        [Fact]
        public void Busqueda_3_Vector_1_2_MaxEnteros_ShouldBe3() //Clase equivalencia: 1,3,5
        {

            string numero = "3";
            string[] vector = { "1", "2","3", "2147483647" };

            string resultado = VectorPosicion.Busqueda(numero, vector);

            Assert.Equal("3", resultado);

        }


    }
}
