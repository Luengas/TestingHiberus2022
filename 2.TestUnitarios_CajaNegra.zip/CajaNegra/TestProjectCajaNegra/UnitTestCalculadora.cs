using System;
using Xunit;

using CajaNegra;

namespace TestProjectCajaNegra
{
    public class UnitTestCalculadora
    {
        [Fact]
        public void Sumar_6_3_ShouldBe9() 
        {

            string x = "6";
            string y = "3";

            string resultado = Calculadora.Sumar(x, y);

            Assert.Equal("9", resultado);

        }

        [Fact]
        public void Restar_6_3_ShouldBe3()
        {

            string x = "6";
            string y = "3";

            string resultado = Calculadora.Restar(x, y);

            Assert.Equal("3", resultado);

        }

        [Fact]
        public void Multiplicar_6_3_ShouldBe18()
        {

            string x = "6";
            string y = "3";

            string resultado = Calculadora.Multiplicar(x, y);

            Assert.Equal("18", resultado);

        }

        [Fact]
        public void Dividir_6_3_ShouldBe2()
        {

            string x = "6";
            string y = "3";

            string resultado = Calculadora.Dividir(x, y);

            Assert.Equal("2", resultado);

        }

        [Fact]
        public void Factorial_3_ShouldBe6()
        {

            string x = "3";

            string resultado = Calculadora.Factorial(x);

            Assert.Equal("6", resultado);

        }

        [Fact]
        public void Exponente_2_3_ShouldBe8()
        {

            string x = "2";
            string y = "3";

            string resultado = Calculadora.Exponente(x,y);

            Assert.Equal("8", resultado);

        }

        [Fact]
        public void Dividir_6_0_ShouldBeError()
        {

            string x = "6";
            string y = "0";

            string resultado = Calculadora.Dividir(x, y);

            Assert.Equal("Error", resultado);

        }


        [Fact]
        public void Sumar_Null_3_ShouldBeError()
        {

            string x = null;
            string y = "3";

            string resultado = Calculadora.Sumar(x, y);

            Assert.Equal("Error", resultado);

        }

        [Fact]
        public void Restar_Null_3_ShouldBeError()
        {

            string x = null;
            string y = "3";

            string resultado = Calculadora.Restar(x, y);

            Assert.Equal("Error", resultado);

        }

        [Fact]
        public void Multiplicar_Null_3_ShouldBeError()
        {

            string x = null;
            string y = "3";

            string resultado = Calculadora.Multiplicar(x, y);

            Assert.Equal("Error", resultado);

        }

        [Fact]
        public void Dividir_Null_3_ShouldBeError()
        {

            string x = null;
            string y = "3";

            string resultado = Calculadora.Dividir(x, y);

            Assert.Equal("Error", resultado);

        }

        [Fact]
        public void Factorial_Null_ShouldBeError()
        {

            string x = null;

            string resultado = Calculadora.Factorial(x);

            Assert.Equal("Error", resultado);

        }

        [Fact]
        public void Exponente_Null_3_ShouldBeError()
        {

            string x = null;
            string y = "3";

            string resultado = Calculadora.Exponente(x, y);

            Assert.Equal("Error", resultado);

        }



        [Fact]
        public void Sumar_a_3_ShouldBeError()
        {

            string x = "a";
            string y = "3";

            string resultado = Calculadora.Sumar(x, y);

            Assert.Equal("Error", resultado);

        }

        [Fact]
        public void Restar_a_3_ShouldBeError()
        {

            string x = "a";
            string y = "3";

            string resultado = Calculadora.Restar(x, y);

            Assert.Equal("Error", resultado);

        }

        [Fact]
        public void Multiplicar_a_3_ShouldBeError()
        {

            string x = "a";
            string y = "3";

            string resultado = Calculadora.Multiplicar(x, y);

            Assert.Equal("Error", resultado);

        }

        [Fact]
        public void Dividir_a_3_ShouldBeError()
        {

            string x = "a";
            string y = "3";

            string resultado = Calculadora.Dividir(x, y);

            Assert.Equal("Error", resultado);

        }

        [Fact]
        public void Factorial_a_ShouldBeError()
        {

            string x = "a";

            string resultado = Calculadora.Factorial(x);

            Assert.Equal("Error", resultado);

        }

        [Fact]
        public void Exponente_a_3_ShouldBeError()
        {

            string x = "a";
            string y = "3";

            string resultado = Calculadora.Exponente(x, y);

            Assert.Equal("Error", resultado);

        }


    }
}
