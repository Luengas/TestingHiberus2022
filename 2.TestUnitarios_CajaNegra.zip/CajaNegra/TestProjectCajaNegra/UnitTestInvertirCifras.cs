using System;
using Xunit;

using CajaNegra;

namespace TestProjectCajaNegra
{
    public class UnitTestInvertirCifras
    {
        [Fact]
        public void Invertir_12_ShouldBe21()
        {

            string numero = "12";

            string resultado = InvertirCifras.Invertir(numero);

            Assert.Equal("21", resultado);

        }


        [Fact]
        public void Invertir_SinParametro_ShouldBeError() //Clase equivalencia: 2.1
        {

            string numero = null;

            string resultado = InvertirCifras.Invertir(numero);

            Assert.Equal("Error", resultado);

        }

        [Fact]
        public void Invertir_Menos30_ShouldBeError() //Clase equivalencia: 4
        {

            string numero = "-30";

            string resultado = InvertirCifras.Invertir(numero);

            Assert.Equal("Error", resultado);

        }

        [Fact]
        public void Invertir_a_ShouldBeError() //Clase equivalencia: 4
        {

            string numero = "a";

            string resultado = InvertirCifras.Invertir(numero);

            Assert.Equal("Error", resultado);

        }


        [Fact]
        public void Invertir_Menor10_ShouldBeError() //Clase equivalencia: 6.1
        {

            string numero = "9";

            string resultado = InvertirCifras.Invertir(numero);

            Assert.Equal("Error", resultado);

        }

        [Fact]
        public void Invertir_Mayor999999999_ShouldBeError() //Clase equivalencia: 6.2
        {

            string numero = "1000000000";

            string resultado = InvertirCifras.Invertir(numero);

            Assert.Equal("Error", resultado);

        }

  
        [Fact]
        public void Invertir_Menos7_ShouldBeError() //Clase equivalencia: 6.1
        {

            string numero = "-7";

            string resultado = InvertirCifras.Invertir(numero);

            Assert.Equal("Error", resultado);

        }

    }
}
