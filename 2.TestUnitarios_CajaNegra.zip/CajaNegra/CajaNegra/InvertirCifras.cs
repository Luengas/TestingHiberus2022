﻿using System;

namespace CajaNegra
{
    public static class InvertirCifras
    {
        public static string Invertir(string numero)
        {
            string res = "";
            int num = 0; 
            try            
            {
                num = Int32.Parse(numero);
                if (num > 9 && num <= 999999999)
                    res = InvertirManualmente(numero);
                else
                    res = "Error";
            }
            catch
            {
                res = "Error";
            }

            return res;
        }


        private static string InvertirManualmente(string cadena)
        {
            string cadenaInvertida = "";
            // Recorrer cadena letra por letra
            foreach (char letra in cadena)
            {
                // Anteponer la letra a la cadena invertida
                cadenaInvertida = letra + cadenaInvertida;
            }
            return cadenaInvertida;
        }
    }


    
}
