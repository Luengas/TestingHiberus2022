﻿using System;

namespace CajaNegra
{
    public static class Calculadora
    {
        public static string Sumar(string x, string y)
        {
            string res = "";
            int suma = 0;

            try
            {
                suma = Int32.Parse(x) + Int32.Parse(y);
                res = suma.ToString();
            }
            catch
            {
                res = "Error";
            }

            return res;
        }


        public static string Restar(string x, string y)
        {
            string res = "";
            int resta = 0;

            try
            {
                resta = Int32.Parse(x) - Int32.Parse(y);
                res = resta.ToString();
            }
            catch
            {
                res = "Error";
            }

            return res;
        }


        public static string Multiplicar(string x, string y)
        {
            string res = "";
            int multiplicacion = 0;

            try
            {
                multiplicacion = Int32.Parse(x) * Int32.Parse(y);
                res = multiplicacion.ToString();
            }
            catch
            {
                res = "Error";
            }

            return res;
        }

        public static string Dividir(string x, string y)
        {
            string res = "";
            int division = 0;

            try
            {
                division = Int32.Parse(x) / Int32.Parse(y);
                res = division.ToString();
            }
            catch
            {
                res = "Error";
            }

            return res;
        }

        public static string Factorial(string x)
        {
            string res = "";
            int factorial = 0;

            try
            {
                factorial = fact(Int32.Parse(x));
                res = factorial.ToString();
            }
            catch
            {
                res = "Error";
            }

            return res;
        }

        private static int fact(int n)
        {
            int fact = 1;
            for (int i = 1; i <= n; i++)
            {
                fact *= i;
            }

            return fact;
        }

        public static string Exponente(string x, string y)
        {
            string res = "";
            double calculo = 0;

            try
            {
                calculo = Math.Pow(Int32.Parse(x), Int32.Parse(y));
                res = calculo.ToString();
            }
            catch
            {
                res = "Error";
            }

            return res;
        }

    }


    
}
