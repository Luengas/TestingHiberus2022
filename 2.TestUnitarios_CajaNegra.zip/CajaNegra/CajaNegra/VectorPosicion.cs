﻿using System;

namespace CajaNegra
{
    public static class VectorPosicion
    {
        public static string Busqueda(string numero, string[] vector)
        {
            string res = "-1";
            int num = 0;
            int numVector = 0;
            try            
            {
                num = Int32.Parse(numero);
                if (vector.Length < 1)
                {
                    res = "-1";
                }
                else
                {
                    for (int pos = 0; pos < vector.Length; pos++)//Recorre todo el arreglo
                    {
                        numVector = Int32.Parse(vector[pos]);
                        if (num == numVector)
                        {
                            pos++;
                            res = pos.ToString();
                        }
                    }
                }
                
            }
            catch
            {
                res = "Error";
            }

            return res;
        }
 
    }


    
}
