﻿using System;

namespace CajaNegra
{
    public static class ValidarHora
    {
        public static string Validar(string hora, string minutos)
        {
            string res = "";
            int numHora = 0;
            int numMinutos = 0;
            try            
            {
                numHora = Int32.Parse(hora);
                numMinutos = Int32.Parse(minutos);
                if (numHora > 0 && numHora < 24 && numMinutos > 0 && numMinutos < 60)
                    res = "OK";
                else
                    res = "Error";
            }
            catch
            {
                res = "Error";
            }

            return res;
        }
 
    }


    
}
